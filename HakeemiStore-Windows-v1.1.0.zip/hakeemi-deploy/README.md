# متجر الحكيمي للتخفيضات — الإصدار 1.1.0

حزمة Windows مبنية من آخر كود تم التحقق منه، وتحتوي على الواجهة والخادم وكل مكتبات التشغيل داخل `app\node_modules`.

## التشغيل من CMD

1. ثبّت Node.js 24.x من https://nodejs.org/en/download
2. فك الضغط.
3. شغّل `scripts\setup.bat` مرة واحدة.
4. عدّل `app\.env` وضع `DATABASE_URL` و`SESSION_SECRET`.
5. شغّل `scripts\start.bat`.
6. افتح `http://localhost:3000`.

لا تحذف `app\node_modules`. إذا حذفته شغّل `scripts\install.bat` لإعادة تثبيت المكتبات.

الحزمة المحلية تحتاج PostgreSQL. للنشر العام استخدم ملفات المصدر في GitHub مع `vercel.json`؛ لا تضع `.env` أو أي Secret داخل GitHub.
