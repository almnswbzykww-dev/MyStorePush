@echo off
curl -fsS http://localhost:3000/api/healthz
if errorlevel 1 echo الخادم غير متاح.
pause
