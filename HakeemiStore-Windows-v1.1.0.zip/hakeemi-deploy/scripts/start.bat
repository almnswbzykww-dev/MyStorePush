@echo off
chcp 65001 >nul
title متجر الحكيمي للتخفيضات
cd /d "%~dp0.."
if not exist "app\.env" call "scripts\setup.bat"
where node >nul 2>&1
if errorlevel 1 (
  echo خطأ: ثبّت Node.js 24.x ثم أعد المحاولة.
  start https://nodejs.org/en/download
  pause
  exit /b 1
)
if not exist "app\node_modules" (
  echo المكتبات غير موجودة. شغّل scripts\install.bat.
  pause
  exit /b 1
)
cd /d "app"
set NODE_ENV=production
node --env-file=.env server\index.mjs
