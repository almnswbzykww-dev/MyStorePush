@echo off
chcp 65001 >nul
cd /d "%~dp0..\app"
where npm >nul 2>&1
if errorlevel 1 (
  echo خطأ: ثبّت Node.js لأنه يحتوي npm.
  pause
  exit /b 1
)
npm install --omit=dev
pause
