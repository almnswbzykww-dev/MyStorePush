@echo off
chcp 65001 >nul
cd /d "%~dp0.."
if not exist "app\.env" (
  copy /Y "app\config\.env.example" "app\.env" >nul
  echo تم إنشاء app\.env. افتحه وضع DATABASE_URL و SESSION_SECRET.
  notepad "app\.env"
  pause
) else (
  echo ملف app\.env موجود بالفعل.
)
