; ==============================================================
; متجر الحكيمي للتخفيضات — Inno Setup Script
; Al-Hakeemi Discount Store — Windows Installer
;
; كيفية إنشاء Setup.exe:
;   1. حمّل Inno Setup المجاني من https://jrsoftware.org/isinfo.php
;   2. افتح هذا الملف في Inno Setup Compiler
;   3. اضغط Build → Compile
;   4. ستجد Setup.exe في مجلد Output
; ==============================================================

[Setup]
AppName=متجر الحكيمي للتخفيضات
AppVersion=1.0.0
AppPublisher=Al-Hakeemi Store
AppPublisherURL=http://localhost:3000
AppSupportURL=http://localhost:3000
AppUpdatesURL=http://localhost:3000
DefaultDirName={autopf}\HakeemiStore
DefaultGroupName=متجر الحكيمي
AllowNoIcons=yes
OutputDir=Output
OutputBaseFilename=HakeemiStore-Setup-v1.0.0
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
SetupIconFile=icons\hakeemi.ico
UninstallDisplayIcon={app}\icons\hakeemi.ico
; Arabic RTL support
RightToLeft=yes
; Require admin for Program Files
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "arabic";   MessagesFile: "compiler:Languages\Arabic.isl"
Name: "english";  MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";     Description: "إنشاء اختصار على سطح المكتب"; GroupDescription: "اختصارات:"; Flags: checkedonce
Name: "startmenuicon";   Description: "إضافة إلى قائمة Start";         GroupDescription: "اختصارات:"; Flags: checkedonce

[Files]
; ملفات التطبيق
Source: "app\*";        DestDir: "{app}\app";        Flags: ignoreversion recursesubdirs createallsubdirs
Source: "scripts\*";    DestDir: "{app}\scripts";    Flags: ignoreversion recursesubdirs
Source: "database\*";   DestDir: "{app}\database";   Flags: ignoreversion recursesubdirs
Source: "docs\*";       DestDir: "{app}\docs";        Flags: ignoreversion recursesubdirs
Source: "icons\*";      DestDir: "{app}\icons";       Flags: ignoreversion recursesubdirs

[Dirs]
Name: "{app}\logs";     Permissions: everyone-modify
Name: "{app}\backup";   Permissions: everyone-modify
Name: "{app}\uploads";  Permissions: everyone-modify

[Icons]
; سطح المكتب
Name: "{autodesktop}\متجر الحكيمي للتخفيضات"; \
      Filename: "wscript.exe"; \
      Parameters: """{app}\scripts\LaunchApp.vbs"""; \
      WorkingDir: "{app}"; \
      IconFilename: "{app}\icons\hakeemi.ico"; \
      Tasks: desktopicon

; قائمة Start
Name: "{group}\متجر الحكيمي للتخفيضات"; \
      Filename: "wscript.exe"; \
      Parameters: """{app}\scripts\LaunchApp.vbs"""; \
      WorkingDir: "{app}"; \
      IconFilename: "{app}\icons\hakeemi.ico"; \
      Tasks: startmenuicon

Name: "{group}\إعداد المتجر";     Filename: "{app}\scripts\setup.bat";       WorkingDir: "{app}"
Name: "{group}\إيقاف المتجر";     Filename: "{app}\scripts\stop.bat";        WorkingDir: "{app}"
Name: "{group}\فحص الصحة";        Filename: "{app}\scripts\healthcheck.bat"; WorkingDir: "{app}"
Name: "{group}\نسخ احتياطي";      Filename: "{app}\scripts\backup.bat";      WorkingDir: "{app}"
Name: "{group}\إلغاء التثبيت";    Filename: "{uninstallexe}"

[Run]
; تشغيل npm install بعد النسخ
Filename: "cmd.exe"; \
  Parameters: "/c cd /d ""{app}\app"" && npm install --production > ""{app}\logs\install.log"" 2>&1"; \
  WorkingDir: "{app}\app"; \
  StatusMsg: "جاري تثبيت المكتبات..."; \
  Flags: runhidden waituntilterminated

; إنشاء .env من المثال
Filename: "cmd.exe"; \
  Parameters: "/c if not exist ""{app}\app\.env"" copy ""{app}\app\config\.env.example"" ""{app}\app\.env"""; \
  Flags: runhidden waituntilterminated

; فتح ملف .env للتعديل
Filename: "notepad.exe"; \
  Parameters: """{app}\app\.env"""; \
  Description: "تعديل إعدادات قاعدة البيانات (.env)"; \
  Flags: postinstall unchecked

; تشغيل المتجر بعد التثبيت
Filename: "wscript.exe"; \
  Parameters: """{app}\scripts\LaunchApp.vbs"""; \
  Description: "تشغيل المتجر الآن"; \
  Flags: postinstall nowait unchecked

[UninstallRun]
Filename: "{app}\scripts\stop.bat"; Flags: runhidden

[Code]
// التحقق من Node.js قبل التثبيت
function InitializeSetup(): Boolean;
var
  NodePath: String;
  ResultCode: Integer;
begin
  Result := True;
  if not Exec('cmd.exe', '/c where node >nul 2>&1', '', SW_HIDE, ewWaitUntilTerminated, ResultCode) or (ResultCode <> 0) then
  begin
    if MsgBox('Node.js غير مثبت على جهازك.' + #13#10 + #13#10 +
              'يرجى تنزيل وتثبيت Node.js (النسخة 18 أو أحدث) من:' + #13#10 +
              'https://nodejs.org/en/download' + #13#10 + #13#10 +
              'هل تريد فتح صفحة التنزيل الآن؟',
              mbConfirmation, MB_YESNO) = IDYES then
    begin
      ShellExec('open', 'https://nodejs.org/en/download', '', '', SW_SHOW, ewNoWait, ResultCode);
    end;
    Result := False;
    MsgBox('أعد تشغيل المثبت بعد تثبيت Node.js.', mbInformation, MB_OK);
  end;
end;
