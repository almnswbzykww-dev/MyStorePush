-- Migration 001 — Initial Schema
-- Run once on a fresh database

\i schema.sql
\i seed.sql
