@echo off
chcp 65001 > nul
title متجر الحكيمي - نسخ احتياطي
color 0A
cd /d "%~dp0.."
set "APPDIR=%CD%"
set "BACKUPDIR=%APPDIR%\backup"
set "DATE_STR=%date:~-4,4%-%date:~-7,2%-%date:~0,2%"
set "TIME_STR=%time:~0,2%-%time:~3,2%"
set "BACKUP_NAME=backup_%DATE_STR%_%TIME_STR%"

if not exist "%BACKUPDIR%" mkdir "%BACKUPDIR%"

echo.
echo [!] جاري إنشاء نسخة احتياطية: %BACKUP_NAME%
echo.

:: نسخ ملف .env
if exist "%APPDIR%\app\.env" (
    if not exist "%BACKUPDIR%\%BACKUP_NAME%" mkdir "%BACKUPDIR%\%BACKUP_NAME%"
    copy "%APPDIR%\app\.env" "%BACKUPDIR%\%BACKUP_NAME%\.env" >nul
    echo [✓] تم نسخ ملف .env
)

:: تصدير قاعدة البيانات (إذا كان pg_dump متاحاً)
where pg_dump >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [!] جاري تصدير قاعدة البيانات...
    if exist "%APPDIR%\app\.env" (
        for /f "tokens=2 delims==" %%a in ('findstr /C."DATABASE_URL" "%APPDIR%\app\.env"') do (
            set DB_URL=%%a
        )
        pg_dump "%DB_URL%" > "%BACKUPDIR%\%BACKUP_NAME%\database.sql" 2>nul
        if %ERRORLEVEL% equ 0 (
            echo [✓] تم تصدير قاعدة البيانات
        ) else (
            echo [!] تعذر تصدير قاعدة البيانات
        )
    )
) else (
    echo [!] pg_dump غير متاح - يمكنك نسخ قاعدة البيانات يدوياً
)

echo.
echo [✓] النسخة الاحتياطية في: %BACKUPDIR%\%BACKUP_NAME%\
echo.
pause
