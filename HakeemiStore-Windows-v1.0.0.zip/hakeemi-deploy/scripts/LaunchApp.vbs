' ==========================================================
' متجر الحكيمي للتخفيضات - مشغّل التطبيق الرئيسي
' LaunchApp.vbs - يعمل بدون نافذة CMD مرئية
' ==========================================================
Option Explicit

Dim WshShell, FSO, AppDir, LogFile, NodePath
Dim Port, MaxWait, Waited

Set WshShell = CreateObject("WScript.Shell")
Set FSO       = CreateObject("Scripting.FileSystemObject")

' مجلد التطبيق (نفس مجلد الـ VBS)
AppDir  = FSO.GetParentFolderName(WScript.ScriptFullName)
LogFile = AppDir & "\logs\launcher.log"
Port    = "3000"

' ─── تسجيل الأحداث ───────────────────────────────────────
Sub Log(msg)
    Dim f
    If Not FSO.FolderExists(AppDir & "\logs") Then
        FSO.CreateFolder AppDir & "\logs"
    End If
    Set f = FSO.OpenTextFile(LogFile, 8, True)   ' 8 = append
    f.WriteLine Now & " | " & msg
    f.Close
End Sub

' ─── البحث عن Node.js ─────────────────────────────────────
Function FindNode()
    Dim Paths, p, Candidate
    ' 1) في PATH
    On Error Resume Next
    Dim result
    result = WshShell.Run("cmd /c where node > """ & AppDir & "\logs\nodepath.tmp"" 2>&1", 0, True)
    If FSO.FileExists(AppDir & "\logs\nodepath.tmp") Then
        Dim ft
        Set ft = FSO.OpenTextFile(AppDir & "\logs\nodepath.tmp", 1)
        If Not ft.AtEndOfStream Then
            Candidate = Trim(ft.ReadLine())
        End If
        ft.Close
        FSO.DeleteFile AppDir & "\logs\nodepath.tmp", True
    End If
    On Error GoTo 0
    If Candidate <> "" And InStr(Candidate, "node.exe") > 0 Then
        FindNode = Candidate : Exit Function
    End If
    ' 2) مسارات التثبيت الشائعة
    Paths = Array( _
        "C:\Program Files\nodejs\node.exe", _
        "C:\Program Files (x86)\nodejs\node.exe", _
        Environ("APPDATA") & "\nvm\current\node.exe", _
        Environ("LOCALAPPDATA") & "\Programs\node\node.exe" _
    )
    For Each p In Paths
        If FSO.FileExists(p) Then FindNode = p : Exit Function
    Next
    FindNode = ""
End Function

' ─── التحقق من تشغيل المنفذ ──────────────────────────────
Function IsPortOpen(ByVal P)
    Dim result
    result = WshShell.Run( _
        "cmd /c netstat -an | findstr /C"":""" & P & """ | findstr LISTENING > nul 2>&1", _
        0, True)
    IsPortOpen = (result = 0)
End Function

' ─── نافذة الانتظار (Splash) ─────────────────────────────
Sub ShowSplash(msg)
    ' نستخدم MsgBox بدون انتظار ليست الحل الأمثل؛
    ' نفضّل wscript.echo للـ silent mode
    Log msg
End Sub

' ════════════════════════════════════════════════════════════
'  البدء الفعلي
' ════════════════════════════════════════════════════════════
Log "=== تشغيل متجر الحكيمي ==="

NodePath = FindNode()
If NodePath = "" Then
    MsgBox "لم يتم العثور على Node.js." & vbCrLf & vbCrLf & _
           "يرجى تثبيت Node.js من الموقع الرسمي:" & vbCrLf & _
           "https://nodejs.org" & vbCrLf & vbCrLf & _
           "بعد التثبيت اضغط مرتين على الأيقونة مرة أخرى.", _
           vbCritical, "متجر الحكيمي - خطأ"
    WScript.Quit 1
End If
Log "Node.js: " & NodePath

' إذا كان الخادم يعمل بالفعل — افتح المتصفح مباشرة
If IsPortOpen(Port) Then
    Log "الخادم يعمل بالفعل على المنفذ " & Port
    WshShell.Run "http://localhost:" & Port, 1, False
    WScript.Quit 0
End If

' تحقق من وجود ملف .env
If Not FSO.FileExists(AppDir & "\app\.env") Then
    MsgBox "ملف الإعدادات (.env) غير موجود!" & vbCrLf & vbCrLf & _
           "يرجى تشغيل setup.bat أولاً لإعداد المتجر.", _
           vbExclamation, "متجر الحكيمي - تنبيه"
    WshShell.Run "explorer """ & AppDir & """", 1, False
    WScript.Quit 1
End If

' تشغيل الخادم في الخلفية
Log "تشغيل الخادم..."
Dim StartCmd
StartCmd = "cmd /c """ & NodePath & """ """ & AppDir & "\app\server\index.mjs"" > """ & _
           AppDir & "\logs\server.log"" 2>&1"
WshShell.Run StartCmd, 0, False   ' 0 = نافذة مخفية

' الانتظار حتى يبدأ الخادم (أقصى 30 ثانية)
MaxWait = 60
Waited  = 0
Do While Not IsPortOpen(Port) And Waited < MaxWait
    WScript.Sleep 500
    Waited = Waited + 1
Loop

If Not IsPortOpen(Port) Then
    Dim LogContent : LogContent = ""
    If FSO.FileExists(AppDir & "\logs\server.log") Then
        Dim fl
        Set fl = FSO.OpenTextFile(AppDir & "\logs\server.log", 1)
        LogContent = fl.ReadAll()
        fl.Close
    End If
    MsgBox "فشل تشغيل الخادم خلال 30 ثانية." & vbCrLf & vbCrLf & _
           "راجع ملف السجلات: " & AppDir & "\logs\server.log" & vbCrLf & vbCrLf & _
           Left(LogContent, 400), _
           vbCritical, "متجر الحكيمي - خطأ"
    WScript.Quit 1
End If

Log "الخادم يعمل - فتح المتصفح"
WshShell.Run "http://localhost:" & Port, 1, False
WScript.Quit 0
