@echo off
chcp 65001 > nul
title متجر الحكيمي - وضع الإنتاج
color 0A
cd /d "%~dp0.."
set "APPDIR=%CD%"
set "PORT=3000"
set NODE_ENV=production

echo.
echo [!] تشغيل المتجر في وضع الإنتاج...
echo.

if not exist "%APPDIR%\app\.env" (
    echo [خطأ] ملف .env غير موجود! شغّل setup.bat أولاً.
    pause & exit /b 1
)

cd /d "%APPDIR%\app"
echo [✓] NODE_ENV=production
echo [✓] PORT=%PORT%
echo [✓] تشغيل الخادم...
echo.

:: تشغيل مع إعادة المحاولة
:retry
node server\index.mjs
if %ERRORLEVEL% neq 0 (
    echo.
    echo [!] توقف الخادم بسبب خطأ. إعادة المحاولة خلال 5 ثوانٍ...
    timeout /t 5 /nobreak >nul
    goto :retry
)
