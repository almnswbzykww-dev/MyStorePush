@echo off
chcp 65001 > nul
title متجر الحكيمي - تثبيت المكتبات
color 0A
cd /d "%~dp0.."
set "APPDIR=%CD%"
echo.
echo [!] جاري تثبيت مكتبات Node.js...
echo.
cd /d "%APPDIR%\app"
call npm install --production
if %ERRORLEVEL% equ 0 (
    echo.
    echo [✓] تم تثبيت المكتبات بنجاح!
) else (
    echo.
    echo [خطأ] فشل التثبيت. راجع الرسائل أعلاه.
)
echo.
pause
