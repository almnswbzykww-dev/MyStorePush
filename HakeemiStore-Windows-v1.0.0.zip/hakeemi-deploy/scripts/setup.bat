@echo off
chcp 65001 > nul
title متجر الحكيمي - الإعداد الأولي
color 0A

cd /d "%~dp0.."
set "APPDIR=%CD%"
set "LOGDIR=%APPDIR%\logs"

if not exist "%LOGDIR%" mkdir "%LOGDIR%"

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   إعداد متجر الحكيمي للتخفيضات        ║
echo  ║   الإعداد الأولي - يرجى الانتظار       ║
echo  ╚══════════════════════════════════════════╝
echo.

:: ─── الخطوة 1: التحقق من Node.js ───────────────────────
echo [1/6] التحقق من Node.js...
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo.
    echo [!] Node.js غير مثبت على جهازك.
    echo.
    echo سيتم فتح صفحة تنزيل Node.js...
    echo بعد التثبيت شغّل هذا الملف مرة أخرى.
    echo.
    start https://nodejs.org/en/download
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo     [✓] Node.js %NODE_VER% موجود

:: ─── الخطوة 2: التحقق من npm ────────────────────────────
echo [2/6] التحقق من npm...
where npm >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo     [خطأ] npm غير موجود! أعد تثبيت Node.js.
    pause & exit /b 1
)
for /f "tokens=*" %%v in ('npm --version') do set NPM_VER=%%v
echo     [✓] npm %NPM_VER% موجود

:: ─── الخطوة 3: إنشاء ملف .env ──────────────────────────
echo [3/6] إعداد ملف البيئة...
if not exist "%APPDIR%\app\.env" (
    if exist "%APPDIR%\app\config\.env.example" (
        copy "%APPDIR%\app\config\.env.example" "%APPDIR%\app\.env" >nul
        echo     [!] تم إنشاء ملف .env
        echo.
        echo  ┌──────────────────────────────────────────┐
        echo  │  هام: يرجى فتح الملف التالي وتعديله:  │
        echo  │  %APPDIR%\app\.env
        echo  │                                          │
        echo  │  عدّل DATABASE_URL و SESSION_SECRET     │
        echo  └──────────────────────────────────────────┘
        echo.
        echo افتح ملف .env الآن؟ (Y/N)
        set /p OPENENV=
        if /i "%OPENENV%"=="Y" (
            notepad "%APPDIR%\app\.env"
            echo.
            echo اضغط Enter بعد التعديل للمتابعة...
            pause >nul
        )
    )
) else (
    echo     [✓] ملف .env موجود
)

:: ─── الخطوة 4: تثبيت المكتبات ──────────────────────────
echo [4/6] تثبيت مكتبات Node.js...
cd /d "%APPDIR%\app"
call npm install --production 2>"%LOGDIR%\npm-install.log"
if %ERRORLEVEL% neq 0 (
    echo     [خطأ] فشل التثبيت! تفاصيل في: %LOGDIR%\npm-install.log
    pause & exit /b 1
)
echo     [✓] تم تثبيت المكتبات

:: ─── الخطوة 5: اختبار الاتصال بقاعدة البيانات ──────────
echo [5/6] اختبار قاعدة البيانات...
cd /d "%APPDIR%\app"
node -e "
const { createRequire } = await import('module');
const req = createRequire(import.meta.url);
try {
  require('dotenv').config({ path: '.env' });
  const { Pool } = require('pg');
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  pool.query('SELECT 1').then(() => { console.log('DB_OK'); pool.end(); }).catch(e => { console.error('DB_FAIL:', e.message); process.exit(1); });
} catch(e) { console.error('DB_FAIL:', e.message); process.exit(1); }
" 2>nul
if %ERRORLEVEL% equ 0 (
    echo     [✓] قاعدة البيانات تعمل
) else (
    echo     [!] تحذير: تعذر الاتصال بقاعدة البيانات
    echo         تأكد من صحة DATABASE_URL في ملف .env
)

:: ─── الخطوة 6: إنشاء الاختصارات ────────────────────────
echo [6/6] إنشاء الاختصار على سطح المكتب...
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%APPDIR%\scripts\CreateShortcut.ps1" 2>nul
if %ERRORLEVEL% equ 0 (
    echo     [✓] تم إنشاء الاختصار على سطح المكتب
) else (
    echo     [!] استخدم CreateShortcut.vbs بدلاً من ذلك
    cscript //nologo "%APPDIR%\scripts\CreateShortcut.vbs" 2>nul
)

echo.
echo  ╔═══════════════════════════════════════════╗
echo  ║   ✓ تم الإعداد بنجاح!                   ║
echo  ║                                           ║
echo  ║   لتشغيل المتجر:                         ║
echo  ║   • ضغطة مزدوجة على أيقونة سطح المكتب  ║
echo  ║   • أو شغّل: scripts\start.bat           ║
echo  ╚═══════════════════════════════════════════╝
echo.
echo اضغط Enter لتشغيل المتجر الآن...
pause >nul
call "%APPDIR%\scripts\start.bat"
