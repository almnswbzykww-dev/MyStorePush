' CreateShortcut.vbs
' بديل PowerShell لإنشاء الاختصارات (لأجهزة التي تمنع PowerShell)
Option Explicit

Dim WshShell, FSO, ScriptDir, AppRoot, LaunchVbs, IconFile

Set WshShell = CreateObject("WScript.Shell")
Set FSO      = CreateObject("Scripting.FileSystemObject")

ScriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)
AppRoot   = FSO.GetParentFolderName(ScriptDir)
LaunchVbs = ScriptDir & "\LaunchApp.vbs"
IconFile  = AppRoot   & "\icons\hakeemi.ico"

' ─── سطح المكتب ────────────────────────────────────────
Dim Desktop, ShortcutPath, oSC
Desktop      = WshShell.SpecialFolders("Desktop")
ShortcutPath = Desktop & "\متجر الحكيمي للتخفيضات.lnk"

Set oSC = WshShell.CreateShortcut(ShortcutPath)
oSC.TargetPath       = "wscript.exe"
oSC.Arguments        = """" & LaunchVbs & """"
oSC.WorkingDirectory = AppRoot
oSC.Description      = "متجر الحكيمي للتخفيضات"
oSC.WindowStyle      = 1
If FSO.FileExists(IconFile) Then oSC.IconLocation = IconFile
oSC.Save()

' ─── قائمة Start ───────────────────────────────────────
Dim StartMenu, AppFolder, oSC2
StartMenu = WshShell.SpecialFolders("StartMenu")
AppFolder = StartMenu & "\Programs\متجر الحكيمي"
If Not FSO.FolderExists(AppFolder) Then FSO.CreateFolder AppFolder

Set oSC2 = WshShell.CreateShortcut(AppFolder & "\متجر الحكيمي للتخفيضات.lnk")
oSC2.TargetPath       = "wscript.exe"
oSC2.Arguments        = """" & LaunchVbs & """"
oSC2.WorkingDirectory = AppRoot
oSC2.Description      = "متجر الحكيمي للتخفيضات"
oSC2.WindowStyle      = 1
If FSO.FileExists(IconFile) Then oSC2.IconLocation = IconFile
oSC2.Save()

MsgBox "✅ تم إنشاء الاختصارات بنجاح!" & vbCrLf & vbCrLf & _
       "• سطح المكتب: متجر الحكيمي للتخفيضات" & vbCrLf & _
       "• قائمة Start: متجر الحكيمي", _
       vbInformation, "متجر الحكيمي"
