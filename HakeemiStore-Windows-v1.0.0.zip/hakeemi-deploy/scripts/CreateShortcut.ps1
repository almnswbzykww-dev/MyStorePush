# CreateShortcut.ps1
# ينشئ اختصار احترافي على سطح المكتب وقائمة Start

$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppRoot     = Split-Path -Parent $ScriptDir
$LaunchVbs   = Join-Path $ScriptDir "LaunchApp.vbs"
$IconFile    = Join-Path $AppRoot   "icons\hakeemi.ico"
$WshShell    = New-Object -ComObject WScript.Shell

# ─── سطح المكتب ────────────────────────────────────────
$DesktopPath = [System.Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "متجر الحكيمي للتخفيضات.lnk"

$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath       = "wscript.exe"
$Shortcut.Arguments        = "`"$LaunchVbs`""
$Shortcut.WorkingDirectory = $AppRoot
$Shortcut.Description      = "متجر الحكيمي للتخفيضات - فتح المتجر"
$Shortcut.WindowStyle      = 1

if (Test-Path $IconFile) {
    $Shortcut.IconLocation = $IconFile
}

$Shortcut.Save()
Write-Host "✓ تم إنشاء اختصار سطح المكتب: $ShortcutPath"

# ─── قائمة Start ───────────────────────────────────────
$StartMenuDir  = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\متجر الحكيمي"
$StartMenuPath = Join-Path $StartMenuDir "متجر الحكيمي للتخفيضات.lnk"

if (-not (Test-Path $StartMenuDir)) {
    New-Item -ItemType Directory -Path $StartMenuDir -Force | Out-Null
}

$SC2 = $WshShell.CreateShortcut($StartMenuPath)
$SC2.TargetPath       = "wscript.exe"
$SC2.Arguments        = "`"$LaunchVbs`""
$SC2.WorkingDirectory = $AppRoot
$SC2.Description      = "متجر الحكيمي للتخفيضات"
$SC2.WindowStyle      = 1

if (Test-Path $IconFile) {
    $SC2.IconLocation = $IconFile
}

$SC2.Save()
Write-Host "✓ تم إنشاء اختصار قائمة Start: $StartMenuPath"

# ─── اختصار الإيقاف ────────────────────────────────────
$StopSC = $WshShell.CreateShortcut((Join-Path $StartMenuDir "إيقاف المتجر.lnk"))
$StopSC.TargetPath       = Join-Path $ScriptDir "stop.bat"
$StopSC.WorkingDirectory = $AppRoot
$StopSC.Description      = "إيقاف خادم متجر الحكيمي"
$StopSC.WindowStyle      = 1
if (Test-Path $IconFile) { $StopSC.IconLocation = $IconFile }
$StopSC.Save()

Write-Host ""
Write-Host "═══════════════════════════════════════"
Write-Host "  ✅ تم إنشاء جميع الاختصارات بنجاح!"
Write-Host "═══════════════════════════════════════"
