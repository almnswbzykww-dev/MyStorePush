@echo off
chcp 65001 > nul
title متجر الحكيمي - تشخيص وإصلاح
color 0E
cd /d "%~dp0.."
set "APPDIR=%CD%"

echo.
echo  ╔════════════════════════════════════════╗
echo  ║   أداة التشخيص والإصلاح التلقائي    ║
echo  ╚════════════════════════════════════════╝
echo.

:: 1. Node.js
echo [تشخيص 1/5] Node.js...
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo   ✗ غير مثبت — يرجى تنزيله من https://nodejs.org
    start https://nodejs.org
    goto :report
) else (
    echo   ✓ موجود
)

:: 2. ملف .env
echo [تشخيص 2/5] ملف .env...
if not exist "%APPDIR%\app\.env" (
    echo   ✗ غير موجود — إنشاء نسخة تجريبية...
    copy "%APPDIR%\app\config\.env.example" "%APPDIR%\app\.env" >nul 2>&1
    echo   ✓ تم إنشاؤه — يرجى تحديث DATABASE_URL
    notepad "%APPDIR%\app\.env"
) else (
    echo   ✓ موجود
)

:: 3. node_modules
echo [تشخيص 3/5] المكتبات...
if not exist "%APPDIR%\app\node_modules" (
    echo   ✗ غير موجودة — تثبيت تلقائي...
    cd /d "%APPDIR%\app"
    npm install --production
    echo   ✓ تم التثبيت
) else (
    echo   ✓ موجودة
)

:: 4. منفذ مشغول
echo [تشخيص 4/5] المنافذ...
netstat -an | findstr /C.":3000 " | findstr LISTENING >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo   ! المنفذ 3000 مشغول
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr /C.":3000 " ^| findstr LISTENING 2^>nul') do (
        echo   ! العملية PID: %%a
        set /p KILL_IT="  هل تريد إيقافها وإعادة التشغيل؟ (Y/N): "
        if /i "!KILL_IT!"=="Y" taskkill /F /PID %%a >nul 2>&1
    )
) else (
    echo   ✓ المنفذ 3000 متاح
)

:: 5. الاختصار
echo [تشخيص 5/5] اختصار سطح المكتب...
set DESKTOP=%USERPROFILE%\Desktop
if not exist "%DESKTOP%\متجر الحكيمي للتخفيضات.lnk" (
    echo   ✗ غير موجود — إنشاء تلقائي...
    cscript //nologo "%APPDIR%\scripts\CreateShortcut.vbs"
) else (
    echo   ✓ موجود
)

:report
echo.
echo  ════════════════════════════════════════
echo  التشخيص اكتمل. شغّل healthcheck.bat للتحقق.
echo  ════════════════════════════════════════
echo.
pause
