@echo off
chcp 65001 > nul
title متجر الحكيمي - استعادة النسخة الاحتياطية
color 0E
cd /d "%~dp0.."
set "APPDIR=%CD%"
set "BACKUPDIR=%APPDIR%\backup"

echo.
echo [!] استعادة النسخة الاحتياطية لمتجر الحكيمي
echo.

if not exist "%BACKUPDIR%" (
    echo [خطأ] مجلد النسخ الاحتياطي غير موجود: %BACKUPDIR%
    pause & exit /b 1
)

echo النسخ الاحتياطية المتاحة:
echo ─────────────────────────
dir /b /ad "%BACKUPDIR%"
echo ─────────────────────────
echo.
set /p BACKUP_NAME="أدخل اسم النسخة للاستعادة: "

if not exist "%BACKUPDIR%\%BACKUP_NAME%" (
    echo [خطأ] النسخة غير موجودة: %BACKUP_NAME%
    pause & exit /b 1
)

:: استعادة .env
if exist "%BACKUPDIR%\%BACKUP_NAME%\.env" (
    copy "%BACKUPDIR%\%BACKUP_NAME%\.env" "%APPDIR%\app\.env" /Y >nul
    echo [✓] تم استعادة ملف .env
)

:: استعادة قاعدة البيانات
if exist "%BACKUPDIR%\%BACKUP_NAME%\database.sql" (
    where psql >nul 2>&1
    if %ERRORLEVEL% equ 0 (
        echo [!] جاري استعادة قاعدة البيانات...
        for /f "tokens=2 delims==" %%a in ('findstr /C."DATABASE_URL" "%APPDIR%\app\.env"') do (
            psql "%%a" < "%BACKUPDIR%\%BACKUP_NAME%\database.sql"
        )
        echo [✓] تم استعادة قاعدة البيانات
    ) else (
        echo [!] psql غير متاح - استعد قاعدة البيانات يدوياً
        echo     الملف: %BACKUPDIR%\%BACKUP_NAME%\database.sql
    )
)

echo.
echo [✓] اكتملت الاستعادة
pause
