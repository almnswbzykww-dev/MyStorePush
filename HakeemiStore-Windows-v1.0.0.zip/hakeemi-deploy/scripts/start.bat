@echo off
chcp 65001 > nul
title متجر الحكيمي للتخفيضات - جاري التشغيل...
color 0B

:: ==========================================================
:: start.bat — تشغيل متجر الحكيمي
:: ==========================================================
cd /d "%~dp0.."
set "APPDIR=%CD%"
set "LOGDIR=%APPDIR%\logs"
set "ENVFILE=%APPDIR%\app\.env"
set "SERVER=%APPDIR%\app\server\index.mjs"
set "PORT=3000"

if not exist "%LOGDIR%" mkdir "%LOGDIR%"
echo [%date% %time%] Starting Hakeemi Store >> "%LOGDIR%\start.log"

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   متجر الحكيمي للتخفيضات          ║
echo  ║   Al-Hakeemi Discount Store v1.0    ║
echo  ╚══════════════════════════════════════╝
echo.

:: ─── التحقق من Node.js ─────────────────────────────────
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [خطأ] Node.js غير مثبت!
    echo.
    echo يرجى تنزيل وتثبيت Node.js من:
    echo https://nodejs.org/en/download
    echo.
    echo بعد التثبيت اضغط Enter للمتابعة...
    start https://nodejs.org/en/download
    pause >nul
    goto :end
)

for /f "tokens=*" %%v in ('node --version 2^>nul') do set NODE_VER=%%v
echo [✓] Node.js: %NODE_VER%

:: ─── التحقق من ملف البيئة ──────────────────────────────
if not exist "%ENVFILE%" (
    echo [تحذير] ملف .env غير موجود - يتم النسخ من المثال...
    if exist "%APPDIR%\app\config\.env.example" (
        copy "%APPDIR%\app\config\.env.example" "%ENVFILE%" >nul
        echo [!] يرجى تحديث DATABASE_URL في الملف: %ENVFILE%
        echo.
        notepad "%ENVFILE%"
        echo بعد تعديل الإعدادات اضغط Enter للمتابعة...
        pause >nul
    ) else (
        echo [خطأ] ملف .env.example غير موجود! شغّل setup.bat أولاً.
        pause
        goto :end
    )
)

:: ─── التحقق من المكتبات ────────────────────────────────
if not exist "%APPDIR%\app\node_modules" (
    echo [!] جاري تثبيت المكتبات... انتظر قليلاً
    cd /d "%APPDIR%\app"
    call npm install --production 2>>"%LOGDIR%\install.log"
    if %ERRORLEVEL% neq 0 (
        echo [خطأ] فشل تثبيت المكتبات! راجع: %LOGDIR%\install.log
        pause
        goto :end
    )
    echo [✓] تم تثبيت المكتبات
)

:: ─── التحقق إذا كان المنفذ مشغولاً ────────────────────
netstat -an | findstr /C:":%PORT% " | findstr LISTENING >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [✓] الخادم يعمل بالفعل على المنفذ %PORT%
    echo.
    echo فتح المتصفح...
    timeout /t 1 /nobreak >nul
    start http://localhost:%PORT%
    goto :end
)

:: ─── تشغيل الخادم ──────────────────────────────────────
echo.
echo [✓] جاري تشغيل الخادم على المنفذ %PORT%...
echo [!] لا تغلق هذه النافذة — أغلقها فقط عند انتهاء العمل.
echo.

cd /d "%APPDIR%\app"
set NODE_ENV=production

:: تشغيل الخادم وانتظار 4 ثوانٍ ثم فتح المتصفح
start /B node server\index.mjs >> "%LOGDIR%\server.log" 2>&1

echo جاري الانتظار لبدء الخادم...
timeout /t 4 /nobreak >nul

:: التحقق من نجاح التشغيل
netstat -an | findstr /C:":%PORT% " | findstr LISTENING >nul 2>&1
if %ERRORLEVEL% neq 0 (
    timeout /t 3 /nobreak >nul
    netstat -an | findstr /C.":%PORT% " | findstr LISTENING >nul 2>&1
)

echo [✓] الخادم يعمل!
echo.
echo  المتجر متاح على: http://localhost:%PORT%
echo.
echo  ┌─────────────────────────────────┐
echo  │  اضغط أي مفتاح لفتح المتصفح  │
echo  └─────────────────────────────────┘
pause >nul
start http://localhost:%PORT%

:end
echo.
echo [%date% %time%] Done >> "%LOGDIR%\start.log"
