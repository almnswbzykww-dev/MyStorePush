@echo off
chcp 65001 > nul
title متجر الحكيمي - تحديث المكتبات
color 0B
cd /d "%~dp0.."
set "APPDIR=%CD%"

echo.
echo [!] جاري تحديث مكتبات Node.js...
echo.
call "%~dp0backup.bat"
cd /d "%APPDIR%\app"
call npm update --production
echo.
echo [✓] اكتمل التحديث
pause
