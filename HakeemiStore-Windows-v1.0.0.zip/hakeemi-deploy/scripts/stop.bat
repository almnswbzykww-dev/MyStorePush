@echo off
chcp 65001 > nul
title متجر الحكيمي - إيقاف الخادم
color 0C

echo.
echo [!] جاري إيقاف خادم متجر الحكيمي...
echo.

:: إيقاف أي عملية node.js تعمل على المنفذ 3000
for /f "tokens=5" %%a in ('netstat -aon ^| findstr /C.":3000 " ^| findstr LISTENING 2^>nul') do (
    echo [✓] إيقاف العملية PID: %%a
    taskkill /F /PID %%a >nul 2>&1
)

:: كبديل - إيقاف كل عمليات node
taskkill /F /IM node.exe >nul 2>&1

echo [✓] تم إيقاف الخادم بنجاح.
echo.
timeout /t 2 /nobreak >nul
