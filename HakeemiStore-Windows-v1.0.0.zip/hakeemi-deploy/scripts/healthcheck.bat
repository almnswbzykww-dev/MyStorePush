@echo off
chcp 65001 > nul
title متجر الحكيمي - فحص الصحة
color 0B
cd /d "%~dp0.."
set "APPDIR=%CD%"
set "PORT=3000"
set "ALL_OK=1"

echo.
echo  ╔══════════════════════════════════════╗
echo  ║   فحص حالة متجر الحكيمي           ║
echo  ╚══════════════════════════════════════╝
echo.

:: Node.js
echo [1] Node.js...
where node >nul 2>&1
if %ERRORLEVEL% equ 0 (
    for /f %%v in ('node --version') do echo     ✓ Node.js %%v
) else (
    echo     ✗ Node.js غير مثبت
    set "ALL_OK=0"
)

:: ملف .env
echo [2] ملف الإعدادات (.env)...
if exist "%APPDIR%\app\.env" (
    echo     ✓ موجود
) else (
    echo     ✗ غير موجود - شغّل setup.bat
    set "ALL_OK=0"
)

:: node_modules
echo [3] المكتبات (node_modules)...
if exist "%APPDIR%\app\node_modules" (
    echo     ✓ موجودة
) else (
    echo     ✗ غير موجودة - شغّل install.bat
    set "ALL_OK=0"
)

:: الخادم على المنفذ
echo [4] الخادم (المنفذ %PORT%)...
netstat -an | findstr /C.":%PORT% " | findstr LISTENING >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo     ✓ يعمل على http://localhost:%PORT%
) else (
    echo     ! لا يعمل - شغّل start.bat
)

:: اختبار HTTP
echo [5] اختبار HTTP API...
curl -s -o nul -w "%%{http_code}" http://localhost:%PORT%/api/healthz > "%APPDIR%\logs\hc_tmp.txt" 2>nul
if exist "%APPDIR%\logs\hc_tmp.txt" (
    set /p HTTP_CODE= < "%APPDIR%\logs\hc_tmp.txt"
    del "%APPDIR%\logs\hc_tmp.txt" >nul 2>&1
    if "%HTTP_CODE%"=="200" (
        echo     ✓ API يستجيب بنجاح (HTTP 200)
    ) else (
        echo     ! API لا يستجيب (HTTP %HTTP_CODE%)
    )
) else (
    echo     ! curl غير متاح للاختبار
)

echo.
if "%ALL_OK%"=="1" (
    echo  ✅ جميع الفحوصات نجحت - المتجر جاهز
) else (
    echo  ⚠️  يوجد مشاكل تحتاج معالجة - راجع أعلاه
)
echo.
pause
