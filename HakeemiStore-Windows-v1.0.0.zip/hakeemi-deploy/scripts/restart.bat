@echo off
chcp 65001 > nul
title متجر الحكيمي - إعادة التشغيل
color 0E
echo.
echo [!] جاري إعادة تشغيل متجر الحكيمي...
call "%~dp0stop.bat"
timeout /t 2 /nobreak >nul
call "%~dp0start.bat"
