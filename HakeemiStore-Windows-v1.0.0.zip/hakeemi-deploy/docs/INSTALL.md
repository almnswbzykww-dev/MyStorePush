# دليل التثبيت — متجر الحكيمي للتخفيضات

## المتطلبات

### 1. Node.js (إلزامي)
- النسخة المطلوبة: 18 أو أحدث
- رابط التنزيل: https://nodejs.org/en/download
- اختر **Windows Installer (.msi)** للتثبيت السهل

### 2. قاعدة البيانات PostgreSQL
اختر أحد الخيارات:

#### أ) سحابية مجانية (موصى بها للمبتدئين)
| الخدمة | الرابط | الملاحظة |
|--------|--------|---------|
| **Neon** | https://neon.tech | مجاني، سريع |
| **Supabase** | https://supabase.com | مجاني، واجهة رسومية |
| **Railway** | https://railway.app | مجاني $5/شهر |

#### ب) محلية
- حمّل PostgreSQL: https://www.postgresql.org/download/windows/
- ثبّته مع PgAdmin
- أنشئ قاعدة بيانات باسم `hakeemi`

---

## خطوات التثبيت

### الخطوة 1: تحضير قاعدة البيانات

**لـ Neon (مثال):**
1. اذهب إلى https://neon.tech وأنشئ حساباً
2. أنشئ مشروعاً جديداً
3. انسخ **Connection String** (يبدأ بـ `postgresql://`)
4. في SQL Editor، شغّل `database\schema.sql` ثم `database\seed.sql`

### الخطوة 2: تشغيل المثبت
```
1. انقر مرتين على install.bat
2. اتبع التعليمات
3. عند فتح ملف .env:
   - غيّر DATABASE_URL برابط قاعدة بياناتك
   - غيّر SESSION_SECRET بكلمة سرية عشوائية طويلة
   - احفظ الملف
4. اضغط Enter للمتابعة
```

### الخطوة 3: تشغيل المتجر
انقر مرتين على أيقونة **متجر الحكيمي للتخفيضات** على سطح المكتب.

---

## مثال على ملف .env

```env
PORT=3000
NODE_ENV=production
DATABASE_URL=postgresql://neondb_owner:abc123@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require
SESSION_SECRET=my-super-secret-key-change-this-now-2026
```

---

## إعداد قاعدة البيانات يدوياً

إذا كان psql متاحاً على جهازك:
```cmd
psql "postgresql://USER:PASS@HOST:5432/DB" < database\schema.sql
psql "postgresql://USER:PASS@HOST:5432/DB" < database\seed.sql
```

إذا كنت تستخدم PgAdmin أو Neon SQL Editor:
1. افتح `database\schema.sql` بأي محرر نصوص
2. انسخ المحتوى
3. الصقه في SQL Editor وشغّله
4. كرر نفس الخطوة مع `database\seed.sql`

---

## بيانات الدخول الافتراضية

| | |
|--|--|
| **رابط لوحة التحكم** | http://localhost:3000/admin-login |
| **رقم المستخدم** | 1 |
| **كلمة المرور** | 123456 |

⚠️ **هام:** غيّر كلمة المرور بعد أول دخول!

---

## بناء Setup.exe

1. حمّل **Inno Setup** مجاناً: https://jrsoftware.org/isinfo.php
2. افتح `Setup.iss` في برنامج Inno Setup
3. اضغط **Build → Compile** أو F9
4. ستجد `HakeemiStore-Setup-v1.0.0.exe` في مجلد `Output\`

---

## حل المشاكل

| المشكلة | الحل |
|---------|------|
| "Node.js غير مثبت" | حمّله من https://nodejs.org |
| "خطأ في قاعدة البيانات" | راجع DATABASE_URL في ملف .env |
| "المنفذ 3000 مشغول" | شغّل stop.bat ثم start.bat |
| الصفحة لا تفتح | انتظر 10 ثوانٍ وأعد المحاولة |
| خطأ عند تثبيت المكتبات | شغّل install.bat |

للمزيد من المساعدة: راجع `logs\server.log`
