# متجر الحكيمي للتخفيضات
## Al-Hakeemi Discount Store — v1.0.0

> متجر إلكتروني احترافي لبيع الأحذية بأفضل الأسعار  
> Professional e-commerce store for shoes with the best prices

---

## 🚀 التشغيل السريع على Windows

### الطريقة 1: استخدام المثبت (موصى بها)

```
1. شغّل Setup.exe
2. اتبع خطوات التثبيت
3. عدّل ملف .env بمعلومات قاعدة البيانات
4. اضغط مرتين على أيقونة سطح المكتب
```

### الطريقة 2: التشغيل اليدوي

```
1. فك ضغط الملفات
2. شغّل scripts\setup.bat (مرة واحدة فقط)
3. عدّل app\.env بمعلومات قاعدة البيانات
4. اضغط مرتين على أيقونة سطح المكتب
   أو شغّل scripts\start.bat
```

---

## ⚙️ المتطلبات

| المتطلب | النسخة | الرابط |
|---------|--------|--------|
| Node.js | 18+ | https://nodejs.org |
| PostgreSQL | 14+ | https://www.postgresql.org OR استخدم Supabase/Neon |

> **ملاحظة:** التطبيق يستخدم قاعدة بيانات PostgreSQL. يمكنك استخدام:
> - قاعدة بيانات محلية: ثبّت PostgreSQL على جهازك
> - قاعدة بيانات سحابية مجانية: https://neon.tech أو https://supabase.com

---

## 📁 هيكل المجلدات

```
HakeemiStore\
├── app\                    ← ملفات التطبيق
│   ├── server\             ← خادم Node.js (Express API)
│   │   └── index.mjs       ← نقطة الدخول الرئيسية
│   ├── public\             ← واجهة React المبنية
│   │   ├── index.html
│   │   └── assets\
│   ├── config\
│   │   └── .env.example    ← مثال إعدادات البيئة
│   ├── .env                ← إعداداتك (أنشأت بعد التثبيت)
│   └── package.json
├── database\               ← ملفات قاعدة البيانات
│   ├── schema.sql          ← هيكل الجداول
│   ├── seed.sql            ← بيانات تجريبية
│   └── migrations\
├── scripts\                ← ملفات التشغيل
│   ├── LaunchApp.vbs       ← المشغّل الرئيسي (بدون نافذة)
│   ├── start.bat           ← تشغيل الخادم
│   ├── stop.bat            ← إيقاف الخادم
│   ├── setup.bat           ← الإعداد الأولي
│   ├── healthcheck.bat     ← فحص الصحة
│   ├── doctor.bat          ← تشخيص وإصلاح
│   ├── backup.bat          ← نسخ احتياطي
│   └── restore.bat         ← استعادة النسخة
├── icons\
│   └── hakeemi.ico         ← أيقونة المتجر
├── logs\                   ← سجلات التشغيل (تُنشأ تلقائياً)
├── backup\                 ← النسخ الاحتياطية
└── Setup.iss               ← ملف بناء المثبت (Inno Setup)
```

---

## 🔧 ملف الإعدادات (.env)

```env
PORT=3000
NODE_ENV=production
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME
SESSION_SECRET=your-very-long-secret-key-here
```

### الحصول على DATABASE_URL مجاناً:

**Neon (موصى به):**
1. اذهب إلى https://neon.tech
2. أنشئ حساباً مجانياً
3. أنشئ قاعدة بيانات جديدة
4. انسخ connection string وضعه في DATABASE_URL

**Supabase:**
1. اذهب إلى https://supabase.com
2. أنشئ مشروعاً جديداً
3. اذهب إلى Settings → Database
4. انسخ URI وضعه في DATABASE_URL

---

## 🗄️ إعداد قاعدة البيانات

بعد إنشاء قاعدة البيانات، شغّل هذه الأوامر:

```bash
# تطبيق الهيكل
psql DATABASE_URL < database\schema.sql

# إضافة البيانات التجريبية  
psql DATABASE_URL < database\seed.sql
```

---

## 👤 بيانات الدخول الافتراضية

| النوع | البيانات |
|-------|----------|
| **لوحة التحكم** | الرابط: `http://localhost:3000/admin-login` |
| رقم المستخدم | `1` |
| كلمة المرور | `123456` |

---

## 📋 ملفات التشغيل

| الملف | الوظيفة |
|-------|---------|
| `scripts\LaunchApp.vbs` | **المشغّل الرئيسي** — يفتح المتجر بنقرة مزدوجة |
| `scripts\start.bat` | تشغيل الخادم مع نافذة |
| `scripts\stop.bat` | إيقاف الخادم |
| `scripts\restart.bat` | إعادة التشغيل |
| `scripts\setup.bat` | الإعداد الأولي (مرة واحدة) |
| `scripts\install.bat` | تثبيت/إعادة تثبيت المكتبات |
| `scripts\healthcheck.bat` | فحص حالة النظام |
| `scripts\doctor.bat` | تشخيص وإصلاح المشاكل تلقائياً |
| `scripts\backup.bat` | نسخ احتياطي |
| `scripts\restore.bat` | استعادة نسخة احتياطية |
| `scripts\update.bat` | تحديث المكتبات |
| `scripts\production.bat` | تشغيل وضع الإنتاج مع إعادة المحاولة |
| `scripts\CreateShortcut.ps1` | إنشاء الاختصارات (PowerShell) |
| `scripts\CreateShortcut.vbs` | إنشاء الاختصارات (VBScript) |

---

## 🔗 روابط المتجر

بعد التشغيل:

| الصفحة | الرابط |
|--------|--------|
| الصفحة الرئيسية | http://localhost:3000 |
| المنتجات | http://localhost:3000/products |
| سلة التسوق | http://localhost:3000/cart |
| تسجيل الدخول | http://localhost:3000/login |
| إنشاء حساب | http://localhost:3000/register |
| لوحة التحكم | http://localhost:3000/admin-login |
| فحص API | http://localhost:3000/api/healthz |

---

## ❓ حل المشاكل الشائعة

**المتجر لا يفتح:**
```
1. شغّل scripts\doctor.bat لتشخيص المشكلة تلقائياً
2. تأكد من تثبيت Node.js: افتح CMD واكتب: node --version
3. تأكد من صحة DATABASE_URL في ملف app\.env
4. راجع السجلات في: logs\server.log
```

**خطأ في قاعدة البيانات:**
```
1. تأكد من صحة DATABASE_URL في app\.env
2. تأكد من تشغيل schema.sql على قاعدة البيانات
3. تأكد من الاتصال بالإنترنت إذا كنت تستخدم قاعدة سحابية
```

**المنفذ 3000 مشغول:**
```
1. شغّل scripts\stop.bat
2. أو غيّر PORT=3001 في ملف app\.env
3. ثم شغّل start.bat مجدداً
```

---

## 🏗️ بناء Setup.exe

لإنشاء ملف Setup.exe:
1. حمّل Inno Setup: https://jrsoftware.org/isinfo.php
2. افتح `Setup.iss` في Inno Setup Compiler
3. اضغط **Build → Compile** (F9)
4. الملف سيُنشأ في مجلد `Output\`

---

## 📞 معلومات المتجر

- **الاسم:** متجر الحكيمي للتخفيضات
- **الموقع:** إب - حبيش، اليمن
- **الهاتف:** 771312997
- **البريد:** admin@hakeemi.com

---

## 📄 الترخيص

جميع الحقوق محفوظة © 2026 — متجر الحكيمي للتخفيضات
