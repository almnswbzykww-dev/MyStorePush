@echo off
chcp 65001 > nul
title متجر الحكيمي — التثبيت الأولي
color 0A

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║    🏪 متجر الحكيمي للتخفيضات                  ║
echo  ║    Al-Hakeemi Discount Store — Installer v1.0  ║
echo  ╚══════════════════════════════════════════════════╝
echo.
echo  مرحباً بك! سيتم إعداد المتجر على جهازك خلال دقائق.
echo.

:: تشغيل setup.bat الرئيسي
call "%~dp0scripts\setup.bat"
