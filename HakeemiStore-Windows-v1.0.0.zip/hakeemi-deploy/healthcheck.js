#!/usr/bin/env node
// healthcheck.js — يُستخدم من Docker أو Windows Service للتحقق من صحة الخادم
import http from "http";

const PORT = process.env.PORT ?? "3000";

const req = http.request(
  { hostname: "localhost", port: Number(PORT), path: "/api/healthz", method: "GET", timeout: 5000 },
  (res) => {
    if (res.statusCode === 200) {
      console.log("✅ Healthy — HTTP", res.statusCode);
      process.exit(0);
    } else {
      console.error("❌ Unhealthy — HTTP", res.statusCode);
      process.exit(1);
    }
  }
);
req.on("error", (err) => {
  console.error("❌ Cannot reach server:", err.message);
  process.exit(1);
});
req.on("timeout", () => {
  console.error("❌ Request timed out");
  req.destroy();
  process.exit(1);
});
req.end();
