# متجر الحكيمي للتخفيضات - Al-Hakeemi Discount Store

## Overview

Full Arabic e-commerce system for luxury shoes. Located at إب - حبيش، اليمن.
Built as a pnpm monorepo with React + Vite frontend and Express backend. Full RTL Arabic interface.

**Copyright:** حقوق الطبع والنشر © 8/4/2026 - المبرمج المهندس زكريا فيصل العزعزي

**Contact:** WhatsApp/Phone: +967 771312997

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite + TailwindCSS + Framer Motion
- **Backend**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Auth**: Session-based (bcryptjs) + Clerk (Google/Facebook OAuth)
- **Validation**: Zod (zod/v4), drizzle-zod
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Architecture

### Frontend (artifacts/store)
- `/` — Welcome splash page (dark luxury background, WhatsApp button, store address)
- `/login` — Login with email/password + Google + Facebook (Clerk OAuth)
- `/register` — Register with email/password + Google + Facebook (Clerk OAuth)
- `/products` — Product catalog with filters (الكل/نسائي/رجالي/شبابي/والدي)
- `/cart` — Shopping cart with currency selection (USD/SAR/YER) + payment methods
- `/invoice/:id` — Printable invoice
- `/admin` — Admin dashboard (products CRUD, orders, customers, accounting, marketing, settings)
- `/sso-callback` — Clerk OAuth callback page

### Backend (artifacts/api-server)
- `/api/auth/register` — Registration (session-based)
- `/api/auth/login` — Login (session-based)
- `/api/auth/clerk-sync` — Sync Clerk OAuth user to our DB + create session
- `/api/auth/me` — Get current user from session
- `/api/auth/logout` — Destroy session
- `/api/products/*` — CRUD (admin-only for write)
- `/api/orders/*` — Order creation and management
- `/api/customers` — Customer list (admin)
- `/api/dashboard/*` — Stats and recent orders (admin)

### Database Schema (lib/db)
- `users` — User accounts with role (admin/customer)
- `products` — Shoes with Arabic/English names, prices, categories
- `orders` — Customer orders with payment/currency info
- `order_items` — Individual items in orders

## Admin Credentials
- Username (رقم المستخدم): 1
- Password (كلمة المرور): 123456
- Email: admin@hakeemi.com

## Setup After Cloning (GitHub)
بعد استنساخ المشروع من GitHub:
```bash
# 1. انسخ ملف الإعدادات
cp .env.example .env

# 2. عدّل DATABASE_URL في ملف .env بعنوان قاعدة بياناتك

# 3. شغّل سكريبت الإعداد التلقائي (يثبت الحزم + ينشئ الجداول + ينشئ مستخدم المدير)
./scripts/post-merge.sh

# 4. شغّل المشروع
pnpm --filter @workspace/api-server run dev   # سيرفر API على :8080
pnpm --filter @workspace/store run dev        # المتجر على المنفذ المعيّن
```

## Environment Variables Required
- `DATABASE_URL` — رابط PostgreSQL (مثال: `postgresql://user:pass@host:5432/dbname`)
- `SESSION_SECRET` — مفتاح الجلسة (قيمة عشوائية آمنة للإنتاج)

## Product Categories
- `women` - نسائي (14 products)
- `men` - رجالي (14 products)
- `youth` - شبابي (14 products)
- `parents` - والدي (8 products)
Total: 50 products

## Store Info
- Name: متجر الحكيمي للتخفيضات
- Address: إب - حبيش، اليمن
- WhatsApp/Phone: +967 771312997
- WA link: https://wa.me/967771312997

## Features
- 50 luxury shoe products across 4 categories
- Currency support: USD, SAR (×3.75), YER (×250)
- Payment methods: JeebPay, Kuraimi, COD
- Printable invoices
- Admin dashboard with full management (products CRUD with image preview, orders, invoices, customers, accounting, marketing, settings)
- Admin-only product management
- Google & Facebook OAuth login (Clerk)
- Language locked to Arabic (HTML translate="no" + meta notranslate)
- WhatsApp floating button (wa.me/967771312997)
- Full Arabic RTL layout (Tajawal font)
- Beautiful dark navy/gold luxury theme
