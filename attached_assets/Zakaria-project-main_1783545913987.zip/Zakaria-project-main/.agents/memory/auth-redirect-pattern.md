---
name: Auth redirect pattern (wouter + React Query)
description: How to safely redirect after login/logout without white screens or React render errors
---

Calling navigation (setLocation) directly in the render body causes "cannot update a component while rendering a different component" React errors and sometimes white screens.

**Pattern:**
- In login page: use `useEffect(() => { if (isAdmin) setLocation("/admin"); }, [isAdmin])` AND `if (isAdmin) return null;`
- In admin page: use `useEffect(() => { if (!isLoading && !isAdmin) setLocation("/admin-login"); }, [isLoading, isAdmin])` AND show spinner while `isLoading || !isAdmin`
- For instant redirect after login: call `queryClient.setQueryData(getGetMeQueryKey(), data.user)` in onSuccess BEFORE `setLocation("/admin")` so isAdmin updates immediately
- For logout: call `logoutFn(); setLocation("/admin-login");` immediately, don't rely only on the useEffect

**Why:** React doesn't allow state updates (which navigation triggers) during render. useEffect defers them to after render is committed.
