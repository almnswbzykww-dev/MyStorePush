---
name: React component-inside-component bug
description: Components defined inside other components cause remount on every parent render, losing child state
---

If a component like `Card` is defined as `const Card = () => ...` inside another component like `SettingsSection`, React creates a new function reference on every render of the parent. React sees the new reference as a different component type and **unmounts + remounts** all children (including stateful ones like InlineEditField), losing their state (cursor position, editing mode, typed text).

**Why:** React uses referential identity to decide if a component type is the same between renders. A new function = a new type = full remount.

**How to apply:** Always define helper/sub-components at module scope (outside the parent function), or use `useMemo` as a last resort. Never define named components inside render functions.
