import { pool, db, usersTable } from "./index";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

export async function autoSetup(): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username INTEGER UNIQUE,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        phone TEXT,
        role TEXT NOT NULL DEFAULT 'customer',
        permissions TEXT DEFAULT '[]',
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        name_ar TEXT NOT NULL,
        description TEXT NOT NULL,
        description_ar TEXT NOT NULL,
        price DOUBLE PRECISION NOT NULL,
        original_price DOUBLE PRECISION,
        category TEXT NOT NULL,
        image_url TEXT NOT NULL,
        in_stock BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        customer_name TEXT NOT NULL,
        customer_email TEXT NOT NULL,
        customer_phone TEXT NOT NULL,
        customer_address TEXT NOT NULL,
        currency TEXT NOT NULL DEFAULT 'USD',
        payment_method TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        total_amount DOUBLE PRECISION NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );

      CREATE TABLE IF NOT EXISTS order_items (
        id SERIAL PRIMARY KEY,
        order_id INTEGER NOT NULL REFERENCES orders(id),
        product_id INTEGER NOT NULL REFERENCES products(id),
        product_name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        price DOUBLE PRECISION NOT NULL
      );
    `);

    const existing = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.username, 1));

    if (existing.length === 0) {
      const hashedPassword = await bcrypt.hash("123456", 10);
      await db.insert(usersTable).values({
        username: 1,
        name: "زكريا فيصل العزعزي",
        email: "admin@hakeemi.com",
        password: hashedPassword,
        role: "admin",
        permissions: '["all"]',
        phone: "+967771312997",
      });
      console.log("✅ تم إنشاء حساب المدير تلقائياً (رقم: 1 / كلمة المرور: 123456)");
    }

    console.log("✅ قاعدة البيانات جاهزة");
  } finally {
    client.release();
  }
}
