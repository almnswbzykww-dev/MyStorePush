import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

async function seed() {
  console.log("🌱 بدء إعداد قاعدة البيانات...");

  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, 1));

  if (existing.length > 0) {
    console.log("✅ المدير موجود بالفعل:", existing[0].name);
  } else {
    const hashedPassword = await bcrypt.hash("123456", 10);
    const [admin] = await db
      .insert(usersTable)
      .values({
        username: 1,
        name: "زكريا فيصل العزعزي",
        email: "admin@hakeemi.com",
        password: hashedPassword,
        role: "admin",
        permissions: '["all"]',
        phone: "+967771312997",
      })
      .returning();
    console.log("✅ تم إنشاء حساب المدير:", admin.name);
    console.log("   رقم المستخدم: 1");
    console.log("   كلمة المرور: 123456");
  }

  console.log("✅ اكتمل إعداد قاعدة البيانات.");
  process.exit(0);
}

seed().catch(err => {
  console.error("❌ خطأ في إعداد قاعدة البيانات:", err);
  process.exit(1);
});
