#!/bin/bash
set -e

echo "🔄 تشغيل إعداد المشروع..."

# تثبيت الحزم
pnpm install --frozen-lockfile

# رفع مخطط قاعدة البيانات
echo "📦 مزامنة مخطط قاعدة البيانات..."
pnpm --filter @workspace/db run push

# إنشاء البيانات الأساسية (مستخدم المدير إذا لم يكن موجوداً)
echo "🌱 إعداد البيانات الأساسية..."
pnpm --filter @workspace/scripts run seed

echo "✅ اكتمل الإعداد! يمكنك الآن تشغيل المشروع."
