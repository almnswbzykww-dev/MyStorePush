import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";
import { useGetMe, useLogin, useLogout, useRegister, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useUser } from "@clerk/react";

interface User {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  role: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAdmin: boolean;
  loginMutation: ReturnType<typeof useLogin>;
  registerMutation: ReturnType<typeof useRegister>;
  logoutFn: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const { data: sessionUser, isLoading: sessionLoading } = useGetMe();
  const loginMutation = useLogin();
  const registerMutation = useRegister();
  const logoutMutation = useLogout();
  const { user: clerkUser, isLoaded: clerkLoaded } = useUser();
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    if (!clerkLoaded || syncing) return;
    const sessionData = sessionUser as any;
    if (clerkUser && !sessionData?.id) {
      const email = clerkUser.primaryEmailAddress?.emailAddress;
      if (!email) return;
      setSyncing(true);
      fetch("/api/auth/clerk-sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          email,
          name: clerkUser.fullName || clerkUser.firstName || email.split("@")[0],
          clerkId: clerkUser.id,
        }),
      })
        .then((r) => r.json())
        .then(() => {
          queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        })
        .catch(() => {})
        .finally(() => setSyncing(false));
    }
  }, [clerkUser, clerkLoaded, sessionUser, syncing, queryClient]);

  const logoutFn = useCallback(() => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        queryClient.clear();
      },
    });
  }, [logoutMutation, queryClient]);

  const currentUser = sessionUser as User | undefined;
  const isLoading = sessionLoading || syncing;

  return (
    <AuthContext.Provider
      value={{
        user: currentUser ?? null,
        isLoading,
        isAdmin: currentUser?.role === "admin",
        loginMutation,
        registerMutation,
        logoutFn,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
