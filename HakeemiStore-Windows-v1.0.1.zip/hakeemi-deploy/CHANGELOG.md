# Changelog

## v1.0.1
- Updated API and storefront build.
- Added Excel product import with preview and validation.
- Added PostgreSQL inventory and admin notification support.
- Added first-login admin password change enforcement.


## [1.0.0] — 2026-08-06

### إضافات
- واجهة المتجر الكاملة بتصميم احترافي (React + Vite + Tailwind)
- لوحة التحكم للمدير
- نظام تسجيل دخول وإنشاء حسابات
- إدارة المنتجات (إضافة، تعديل، حذف)
- سلة التسوق
- نظام الطلبات مع تتبع الحالة
- إدارة العملاء
- تقارير لوحة التحكم
- نظام تخفيضات (عرض السعر الأصلي والمخفض)
- تصفية المنتجات بالتصنيف والبحث
- صفحة التواصل
- دعم RTL (العربية)
- الوضع المظلم Dark Mode

### الأمان
- تشفير كلمات المرور بـ bcrypt
- جلسات آمنة (express-session)
- حماية من حقن الأدوار
- التحقق من الأسعار على الخادم (منع التلاعب بالأسعار)
- CORS محدود بنطاق التطبيق

### البنية التقنية
- **Frontend:** React 19 + Vite + TailwindCSS + Framer Motion
- **Backend:** Node.js + Express 5 + TypeScript
- **Database:** PostgreSQL + Drizzle ORM
- **Icons:** Lucide + React Icons
- **UI:** Radix UI + shadcn/ui
