-- ============================================================
-- متجر الحكيمي للتخفيضات — Schema SQL
-- Al-Hakeemi Discount Store — Complete Database Schema
-- Version: 1.0.0
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ─── Users ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          SERIAL PRIMARY KEY,
    username    INTEGER UNIQUE,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    password    TEXT NOT NULL,
    must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
    phone       TEXT,
    role        TEXT NOT NULL DEFAULT 'customer'
                    CHECK (role IN ('customer','admin','staff')),
    permissions TEXT DEFAULT '[]',
    created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email    ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_role     ON users(role);

-- ─── Products ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
    id              SERIAL PRIMARY KEY,
    sku             TEXT,
    name            TEXT NOT NULL,
    name_ar         TEXT NOT NULL,
    description     TEXT,
    description_ar  TEXT,
    price           NUMERIC(10,2) NOT NULL,
    original_price  NUMERIC(10,2),
    category        TEXT NOT NULL,
    image_url       TEXT,
    in_stock        BOOLEAN NOT NULL DEFAULT TRUE,
    stock_quantity  INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS products_sku_unique ON products(sku);
CREATE INDEX IF NOT EXISTS idx_products_category  ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_in_stock  ON products(in_stock);
CREATE INDEX IF NOT EXISTS idx_products_name_ar   ON products USING gin(name_ar gin_trgm_ops);

-- ─── Orders ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
    id               SERIAL PRIMARY KEY,
    user_id          INTEGER REFERENCES users(id) ON DELETE SET NULL,
    customer_name    TEXT NOT NULL,
    customer_email   TEXT,
    customer_phone   TEXT,
    customer_address TEXT,
    currency         TEXT NOT NULL DEFAULT 'SAR',
    payment_method   TEXT NOT NULL DEFAULT 'cash',
    status           TEXT NOT NULL DEFAULT 'pending'
                         CHECK (status IN ('pending','confirmed','processing','shipped','delivered','cancelled')),
    total_amount     NUMERIC(12,2) NOT NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_user_id    ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status     ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);

-- ─── Order Items ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS order_items (
    id           SERIAL PRIMARY KEY,
    order_id     INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id   INTEGER REFERENCES products(id) ON DELETE SET NULL,
    product_name TEXT NOT NULL,
    quantity     INTEGER NOT NULL CHECK (quantity > 0),
    price        NUMERIC(10,2) NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id   ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id);

-- ─── Admin Notifications ────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
    id         SERIAL PRIMARY KEY,
    admin_id   INTEGER NOT NULL REFERENCES users(id),
    type       TEXT NOT NULL,
    title      TEXT NOT NULL,
    message    TEXT NOT NULL,
    entity_id  INTEGER,
    is_read    BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_admin_id ON notifications(admin_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(admin_id, is_read);
